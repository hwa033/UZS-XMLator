Place the provided logo image in this path to use it in the app:

  web/static/img/uzs_logo.png

Recommended size: 256x256 or 512x512 (PNG). The template will scale to 36px height in the navbar and the same file is used as favicon.

If you want me to embed the image automatically, reply and I will embed it as a base64 data-uri in the templates or create the PNG file directly if you grant me permission to access the attached image file content.