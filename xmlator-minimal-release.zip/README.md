# XML Automatisering Framework

## 🎉 Wat is er nieuw? (December 2024)

✨ **Optionele Features Geïmplementeerd:**
- 📊 **Dashboard KPI's** - Realtime statistieken van XML generatie
- 📋 **Excel Datasets Dropdown** - Selecteer pre-configured testdata (2437 datasets)
- ✅ **XSD Validatie** - Automatische validatie van gegenereerde XML
- 📈 **Event Logging** - Volg alle XML generatie events in `build/logs/xml_events.jsonl`
- 🔌 **KPI API Endpoints** - `/api/xml/throughput`, `/api/xml/events`, `/api/xml/latest-errors`

**Status:** ✅ 100% Compleet - Productie-klaar!

---

## 🚀 Snel aan de slag

# XML Automatisering

Deze repository bevat een hulpmiddel om XML-aanvragen te genereren, te valideren en te beheren voor UZS-gerelateerde processen. De applicatie bestaat uit een eenvoudige webinterface (Flask) en een set scripts/tests voor geautomatiseerde workflows.

Doelgroepen: testers, ontwikkelaars en beheerders die testberichten willen maken en analyseren.

---

## Inhoud van deze map

- `web/` – de Flask webapplicatie: `app.py`, templates en statische bestanden (CSS/JS).
- `docs/` – documentatie en voorbeeld XSD/XML-bestanden.
  - `DEVELOPER_REFERENCE.md` ⭐ NEW - Developer quick reference
  - `OPTIONELE_FEATURES_IMPLEMENTATIE.md` ⭐ NEW - Optional features details
  - `VOORTGANG_IMPLEMENTATIE.md` - Progress tracking
  - `SESSION_2_SUMMARY.md` ⭐ NEW - Implementation summary
- `uzs_filedrop/` – voorbeeld output-mappen (waar gegenereerde XML-bestanden terechtkomen).
- `build/logs/` – event logging voor KPI dashboard
- `tests.robot` – Robot Framework tests.
- `test_kpi_integration.py` ⭐ NEW - Integration tests for KPI features
- `requirements.txt` – Python afhankelijkheden.

---

## Installatie

1. Maak een virtuele omgeving en activeer deze:

```powershell
python -m venv .venv; .\.venv\Scripts\Activate.ps1
```

2. Installeer de vereisten:

```powershell
pip install -r requirements.txt
```

Dit installeert ook `pydantic`, vereist voor API-validatie (JSON/Excel uploads).

3. Optioneel (development):

```powershell
pip install -r requirements-dev.txt
```

4. ⭐ **NEW** - Installeer lxml voor XSD validatie (optioneel):

```powershell
pip install lxml
```

---

## Starten van de webapp

In de projectroot:

```powershell
# Development
python -m web.app

# Production (met environment variables)
$env:U_XMLATOR_SECRET = "your_secret_key_here"
$env:FLASK_ENV = "production"

---

## Voor testers (makkelijk)

Pak het zipbestand uit via de Verkenner, bijvoorbeeld naar E:\xmlator
Open de map en start de app door run-xmlator.ps1 te openen
De browser opent vanzelf
Log in met admin admin
Instellingen zitten op http://localhost:5000/instellingen
XML bestanden komen standaard in E:\xmlator\build\excel_generated (als er geen filedrop paden zijn ingesteld).
python -m web.app
```

### Lokale quickstart (met huidige repo)

```powershell
# vanuit de projectroot
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

# start met auto-reload voor dev
python run_app.py --reload --host 127.0.0.1 --port 5000

# check
Invoke-WebRequest -Uri "http://127.0.0.1:5000/health" -UseBasicParsing
Invoke-WebRequest -Uri "http://127.0.0.1:5000/ready" -UseBasicParsing
```

Open vervolgens `http://localhost:5000` in uw browser.

### Deployment (kort)

- Docker compose: `docker-compose up -d` (nginx + app, zie `DEPLOY.md`).
- Enkel container: `scripts/deploy_minimal_docker.sh` → http://<server-ip>:5000.
- Windows EXE: bouw met `scripts/build_windows_exe.ps1`, pak met `scripts/package_for_transfer.ps1`, run `run-xmlator.ps1` op de target.

## Secrets and session hardening

For production, set a strong `U_XMLATOR_SECRET` environment variable. The app will refuse to start when `FLASK_ENV=production` and `U_XMLATOR_SECRET` is not set. Recommended session cookie settings are enabled by default (HTTPOnly, Secure, SameSite=Lax). You can override these via environment variables:

- `U_XMLATOR_COOKIE_SECURE` (default `1`) — set to `0` to disable `Secure` (not recommended)
- `U_XMLATOR_SAMESITE` (default `Lax`) — options: `Lax`, `Strict`, `None`
- `U_XMLATOR_SESSION_SECONDS` (default 604800) — session lifetime in seconds

Example (PowerShell):

```powershell
$env:U_XMLATOR_SECRET = 'replace-with-a-strong-random-secret'
python -m web.app
```

De webinterface bevat:
- Dashboard: KPI-tegels, grafieken en snelle acties
- Genereer XML: formulier voor het aanmaken van testberichten
- Resultaten: overzicht van gegenereerde bestanden en details

---

## Belangrijkste onderdelen en opties

- `web/app.py`: centrale Flask-applicatie en API-endpoints (onder andere `/api/xml/throughput`, `/api/xml/events`, `/api/test/uitvoeren`).
- `web/templates/*.html`: Jinja2-templates voor de frontend.
- `web/static/css/dashboard.css`: styling voor dashboard en tegels.
-- `web/static/js/dashboard.js`: client-side logica voor grafieken en interactieve elementen.

---

## XML genereren (voorbeeld)

1. Ga naar de pagina `Genereer XML` in de webinterface of gebruik het script `generate_xml.py`.
2. Kies het type aanvraag (ZBM, VM of Digipoort) en vul de velden (BSN, geboortedatum, naam).
3. De applicatie vult unieke referentievelden automatisch in (datum/tijd + suffix) en slaat het bestand op in de bijbehorende map onder `uzs_filedrop/`.

Bestandspaden die gebruikt worden (standaard):

- ZBM / VM: `uzs_filedrop/UZI-GAP3/UZSx_ACC1/v0428`
- Digipoort (OTP3): `uzs_filedrop/UZI-GAP3/UZSx_ACC1/UwvZwMelding_MQ_V0428`

Als `filedrop_locaties` leeg is, gebruikt de app een lokale fallback:
`web/static/downloads` voor downloadlinks en `build/excel_generated` als outputmap.

De mapping staat in `web/app.py` in `OUTPUT_MAP`.

---

## Tests

Gebruik Robot Framework tests om functionaliteit te controleren:

```powershell
# Voer alle tests uit
robot tests.robot
```

Er is ook een endpoint in de webapp om tests te starten: `POST /api/test/uitvoeren`.

---

## API overzicht

- `GET /api/xml/throughput?days=N` – dagelijkse aantallen en success-percentages (standaard N=7)
-- `GET /api/xml/events?date=YYYY-MM-DD` – ruwe events voor een datum
- `POST /api/test/uitvoeren` – start testuitvoering (Robot Framework)

Zie `web/app.py` voor details en fallback-logica.

---

## Veelvoorkomende problemen & oplossingen

- "Geen XSD gevonden" bij validatie: controleer of de XSD-bestanden in `docs/` aanwezig zijn.
- Bestanden worden niet gegenereerd: controleer schrijfrechten en de `uzs_filedrop/` mappen.
- Stijlen van het dashboard lijken anders: ververs de browsercache (Ctrl+F5) en controleer `web/static/css/dashboard.css`.

---

## Bijdragen

1. Fork de repository
2. Maak een feature-branch
3. Open een pull request met een duidelijke omschrijving

---

Als iets onduidelijk is of u extra uitleg wilt over een onderdeel, laat het weten.